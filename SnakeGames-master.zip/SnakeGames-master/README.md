# SnakeGames
This is FPS(Frame Per Second ) Based 2D simple game 
For more details :https://www.youtube.com/watch?v=aJ1FP1GfWLY&t=1380s
